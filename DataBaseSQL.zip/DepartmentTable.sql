drop table Department;
create table Department(
    Dept_id number(4) primary key,
    Dept_name varchar2(50)
);


insert into Department (Dept_id, Dept_name)
values 
('0001', 'Sales');
insert into Department (Dept_id, Dept_name)
values 
('0002', 'IT');
insert into Department (Dept_id, Dept_name)
values 
('0003', 'Operations');
insert into Department (Dept_id, Dept_name)
values 
('0004', 'Accounting');
insert into Department (Dept_id, Dept_name)
values 
('0005', 'HR');