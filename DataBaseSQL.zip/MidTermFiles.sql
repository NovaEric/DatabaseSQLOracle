drop table Files;

create table Files(
    file_id number(4) primary key,
    file_name varchar2(20),
    file_date_created date default sysdate
);


insert into Files (file_id, file_name)
values 
('001', 'System');
insert into Files (file_id, file_name)
values 
('002', 'Backup');
insert into Files (file_id, file_name)
values 
('003', 'Recovery');
