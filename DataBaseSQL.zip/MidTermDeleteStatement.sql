DELETE FROM Folder
WHERE folder_id = 2;

DELETE FROM Files
WHERE file_id = 2;

