drop table Folder;

create table Folder(
    folder_id number(4) primary key,
    folder_name varchar2(20),
    folder_date_created date default sysdate,
    constraint fk_folder_id foreign key (folder_id) references Files(file_id)    
);


insert into Folder (folder_id, folder_name)
values 
('001', 'System');
insert into Folder (folder_id, folder_name)
values 
('002', 'Backup');
insert into Folder (folder_id, folder_name)
values 
('003', 'Recovery');