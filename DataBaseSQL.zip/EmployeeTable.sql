drop table Employee;
create table Employee(
    Emp_id number(4) primary key,
    Emp_Fname varchar2(50),
    Emp_Lname Varchar2(50),
    Salary Number,
    Dept_num number(4),
    constraint fk_Dept_Num foreign key (Dept_num) references Department(Dept_id)
);


insert into Employee (Emp_id, Emp_Fname, Emp_Lname, Salary, Dept_num)
values 
('0001', 'Mike', 'Tyson', 100000, 0001);
insert into Employee (Emp_id, Emp_Fname, Emp_Lname, Salary, Dept_num)
values 
('0002', 'Al', 'Mitch', 150000, 0002);
insert into Employee (Emp_id, Emp_Fname, Emp_Lname, Salary, Dept_num)
values 
('0003', 'Olfy', 'Ho', 120000, 0003);
insert into Employee (Emp_id, Emp_Fname, Emp_Lname, Salary, Dept_num)
values 
('0004', 'Eric', 'Nova', 180000, 0004);
insert into Employee (Emp_id, Emp_Fname, Emp_Lname, Salary, Dept_num)
values 
('0005', 'Kile', 'Lewis', 210000, 0005);