select * from Files
union 
select * from Folder