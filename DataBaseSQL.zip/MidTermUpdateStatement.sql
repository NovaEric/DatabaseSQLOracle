UPDATE Files
SET file_name = 'Alfred Schmidt'
WHERE file_id = 2;

UPDATE Folder
SET folder_name = 'Alfred Schmidt'
WHERE folder_id = 2;